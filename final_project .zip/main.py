import sys
import tkinter as tk
from tkinter import ttk  # package that help to app to look modern
import student
from student import Student
import json

student_list = student.Sheet()

# Function to save student list to a file
def save_student_list(student_list):
    student_data = [student.to_dict() for student in student_list.students]
    with open('student_list.txt', 'w') as f:
        json.dump(student_data, f)


# Function to load student list from a file
def load_student_list():
    try:
        with open('student_list.txt', 'r') as f:
            student_data = json.load(f)
            lst = []
            for student in student_data:
                lst.append(Student(student["num"], student["name"], student["id"], student["status"], student["grade"]))
            return lst
    except FileNotFoundError:
        return []


# Presentation of the charge
def display_student_information(lst):
    student_list.load_lst(lst)

    # Clear existing rows in the Treeview
    for row in excel_view.get_children():
        excel_view.delete(row)

    student.num_student=1
    # Insert new rows with updated values
    for st in student_list.get_tup_to_lst("!"):
        excel_view.insert('', tk.END, f'Item{student.num_student}', values=st)
        if student.num_student <len(student_list.students):
           student.num_student += 1
    student.num_student -= 1



# Define the load button callback
def load_button_callback():
    students = load_student_list()
    display_student_information(students)


# save sheet func
def save():
    save_student_list(student_list)




# student_list=[("Name","Id", "Pass" , "grades"),('aba','25684552','Pass','87'),('ron','85258','Not Pass','87'),('ahon','741','Pass','87'),('kol','963','Pass','87'),('aba','25684552','Pass','87'),('ron','85258','Not Pass','87'),('ahon','741','Pass','87'),('kol','963','Pass','87'),('aba','25684552','Pass','87'),('ron','85258','Not Pass','87'),('ahon','741','Pass','87'),('kol','963','Pass','87'),('aba','25684552','Pass','87'),('ron','85258','Not Pass','87'),('ahon','741','Pass','87'),('kol','963','Pass','87'),('aba','25684552','Pass','87'),('ron','85258','Not Pass','87'),('ahon','741','Pass','87'),('kol','963','Pass','87'),('aba','25684552','Pass','87'),('ron','85258','Not Pass','87'),('ahon','741','Pass','87'),('kol','963','Pass','87'),('aba','25684552','Pass','87'),('ron','85258','Not Pass','87'),('ahon','741','Pass','87'),('kol','963','Pass','87'),('aba','25684552','Pass','87'),('ron','85258','Not Pass','87'),('ahon','741','Pass','87'),('kol','963','Pass','87'),('aba','25684552','Pass','87'),('ron','85258','Not Pass','87'),('ahon','741','Pass','87'),('kol','963','Pass','87'),('aba','25684552','Pass','87'),('ron','85258','Not Pass','87'),('ahon','741','Pass','87'),('kol','963','Pass','87'),('aba','25684552','Pass','87'),('ron','85258','Not Pass','87'),('ahon','741','Pass','87'),('kol','963','Pass','87')]
student_list.add_student(Student("Number", "Name", "Id", "Pass", "grades"))
student_list.add_student(Student("1", "ron", "21562568", "Pass", "98"))
student_list.add_student(Student("2", "geli", "21562568", "Not Pass", "54"))
student.num_student = 2


# Creating table base data
def data():
    for name in student_list.get_tup_to_lst(0):
        excel_view.heading(name, text=name)
    num = 1
    for st in student_list.get_tup_to_lst("!"):
        excel_view.insert('', tk.END, f'Item{num}', values=st)
        num += 1


# Insert student
def insert_st():
    name = student_name_entry.get()
    id = id_entry.get()
    status = status_combox.get()
    grade = final_grade.get()

    # name
    if len(name) == 0:
        msg.config(text='name cannot be empty')
    else:
        if name == "Name":
            msg.config(text="please insert valid name")
            return False
        if any(ch.isdigit() for ch in name):
            msg.config(text="name cannot have numeric")
            return False
        if len(name) <= 2:
            msg.config(text="minimum 3 character required!")
            return False
        else:
            msg.config(text='')

    # id
    if len(id) == 0:
        msg.config(text='id cannot be empty')
        return False
    else:
        if id.isdigit() == False:
            msg.config(text='id must be only numbers')
            return False
        if len(id) != 9:
            msg.config(text='id must be len 9')
            return False
        else:
            msg.config(text='')
    # grade
    if grade == "Final Grade":
        msg.config(text="please insert valid grade")
        return False
    if grade.isdigit() == False:
        msg.config(text='grade must be only numbers')
        return False
    if len(grade) > 100 or len(grade) < 0:
        msg.config(text='id must be in the range of 0-100')
        return False
    if (status == "Pass" and int(grade) < 60) or (status == "Not Pass" and int(grade) >= 60):
        msg.config(text='The grade status does not match the grade')
        return False
    else:
        msg.config(text='')

    student.num_student += 1

    row = Student(student.num_student, name, id, status, grade)
    student_list.add_student(row)

    excel_view.insert('', tk.END, f'Item{student.num_student}', values=student_list.insetion(student.num_student))

    from_row.config(to=student.num_student)
    to_row.config(to=student.num_student)
    num_spinbox.config(to=student.num_student)

    student_name_entry.delete(0, "end")
    student_name_entry.insert(0, "Name")

    id_entry.delete(0, "end")
    id_entry.insert(0, "Id")

    status_combox.set(combox_optionals[0])

    final_grade.delete(0, "end")
    final_grade.insert(0, "Final Grade")


# Basic calculation function
def cal():
    operation = calcu.get()
    num1 = row_grade.get()
    num2 = num_spinbox.get()

    # numbers
    if len(num1) == 0 or len(num2) == 0:
        msg.config(text='An invoice operation can only be performed between numbers')
        return False
    if num1.isdigit() == False or num2.isdigit() == False:
        msg.config(text='the parameter must be only positive numbers')
        return False
    if int(num2) < 1 or int(num2) > student.num_student:
        msg.config(text='The row does not exist')
        return False
    else:
        msg.config(text='')

    # operation
    if operation != "+" and operation != "*" and operation != "-" and operation != "/":
        msg.config(text='The opreation must be + or * or  - or / ')
        return False

    else:
        msg.config(text='')

    num1 = int(row_grade.get())
    num2 = int(student_list.insetion(int(num_spinbox.get()))[4])


    if operation == "+":
        result = num1 + num2
        if result > 100:
            result = 100
        if result < 0:
            result = 0
    elif operation == "*" :
        result = num1 * num2
        if result>100:
            result=100
        if result<0:
            result=0
    elif operation == "/":
        if num2 != 0:
            result = num2 / num1
            if result > 100:
                result = 100
            if result < 0:
                result = 0
        else:
            result = "Error: Division by zero"
    elif operation == "-":
        result =  num2-num1
        if result > 100:
            result = 100
        if result < 0:
            result = 0
    else:
        result = "Invalid operation"

    lst = student_list.insetion(int(num_spinbox.get()))
    student_list.change_student(int(num_spinbox.get()), lst[1],lst[2], lst[3], str(result))
    excel_view.item(f'Item{num_spinbox.get()}', values=student_list.insetion(int(num_spinbox.get())))

    answer.delete(0, "end")  # Clear previous value
    answer.insert(0, str(result))

    row_grade.delete(0, "end")
    row_grade.insert(0, "number")

    num_spinbox.delete(0, "end")
    num_spinbox.insert(0, "row number")


# Special calculation function
def func_cal():
    num1 = from_row.get()
    num2 = to_row.get()
    operation = func.get()

    if num1.isdigit() == False or num2.isdigit() == False:
        msg.config(text='the parameter must be only positive numbers')
        return False
    if int(num2) < 1 or int(num2) > student.num_student or int(num1) < 1 or int(num1) > student.num_student:
        msg.config(text='The row does not exist')
        return False
        # operation
    if operation != "MIN" and operation != "MAX" and operation != "SUM" and operation != "AVERAGE":
        msg.config(text='The opreation must be MIN or MAX or  SUM or AVERAGE ')
        return False

    else:
        msg.config(text='')
    num1 = int(from_row.get())
    num2 = int(to_row.get())
    grades = student_list.grades()[min(num1, num2) - 1:max(num1, num2)]

    if operation == "MIN":
        result = min(grades)
    elif operation == "MAX":
        result = max(grades)
    elif operation == "AVERAGE":
        if len(grades) == 0:
            result = 0  # Return 0 if the list is empty to avoid division by zero
        else:
            total = sum(grades)
            result = total / len(grades)
    elif operation == "SUM":
        result = sum(grades)
    else:
        result = "Invalid operation"

    answer_func.delete(0, "end")  # Clear previous value
    answer_func.insert(0, str(result))


# Change in student data function
def change_st():
    num = num_change.get()
    name = student_name_change.get()
    id = id_change.get()
    status = status_combox_change.get()
    grade = final_grade_change.get()

    if num.isdigit() == False:
        msg.config(text='the parameter must be only positive numbers')
        return False
    if int(num) < 1 or int(num) > student.num_student:
        msg.config(text='The row does not exist')
        # reset()
        return False
    else:
        msg.config(text='')

        # name
    if len(name) == 0:
        msg.config(text='name cannot be empty')
        # reset()
    else:

        if any(ch.isdigit() for ch in name):
            msg.config(text="name cannot have numeric")
            reset()
            return False
        if name != "Name" and len(name) <= 2:
            msg.config(text="minimum 3 character required!")
            reset()
            return False
        else:
            msg.config(text='')

        # id
    if len(id) == 0:
        msg.config(text='id cannot be empty')
        reset()
        return False
    else:

        if id != "Id" and id.isdigit() == False:
            msg.config(text='id must be only numbers')
            reset()
            return False
        if id != "Id" and len(id) != 9:
            msg.config(text='id must be len 9')
            reset()
            return False
        else:
            msg.config(text='')
        # grade
    if grade != "Final Grade":
        if grade.isdigit() == False:
            msg.config(text='grade must be only numbers')
            reset()
            return False
        if len(grade) > 100 or len(grade) < 0:
            msg.config(text='grade must be in the range of 0-100')
            reset()
            return False
        if (status == "Pass" and int(grade) < 60) or (status == "Not Pass" and int(grade) >= 60):
            msg.config(text='The grade status does not match the grade')
            reset()
            return False
        else:
            msg.config(text='')

    student_list.change_student(int(num), name, id, status, grade)

    excel_view.item(f'Item{num}', values=student_list.insetion(int(num)))

    num_change.delete(0, "end")
    num_change.insert(0, "Number")

    student_name_change.delete(0, "end")
    student_name_change.insert(0, "Name")

    id_change.delete(0, "end")
    id_change.insert(0, "Id")

    status_combox_change.set(combox_optionals_change[0])

    final_grade_change.delete(0, "end")
    final_grade_change.insert(0, "Final Grade")


# Returning the cells to their initial value
def reset():
    num_change.delete(0, "end")
    num_change.insert(0, "Number")

    student_name_change.delete(0, "end")
    student_name_change.insert(0, "Name")

    id_change.delete(0, "end")
    id_change.insert(0, "Id")

    status_combox_change.set(combox_optionals_change[0])

    final_grade_change.delete(0, "end")
    final_grade_change.insert(0, "Final Grade")



# Start of tkinter implementation!

root = tk.Tk()
root.title('excel')
root.geometry('1000x1000+600+300')
root.config(bg='#296b73')

frame = ttk.Frame(root)  # largest box
frame.pack()

# -----------insert student
widgets_frame = ttk.LabelFrame(frame, text="Insert Student")
widgets_frame.grid(row=0, column=0, padx=20, pady=20)

student_name_entry = ttk.Entry(widgets_frame)
student_name_entry.insert(0, "Name")
student_name_entry.bind("<FocusIn>", lambda e: student_name_entry.delete('0', 'end'))
student_name_entry.grid(row=0, column=0, padx=5, pady=(0, 5), sticky="ew")  # east-west

id_entry = ttk.Entry(widgets_frame, validate="focusout")
id_entry.insert(0, "Id")
id_entry.bind("<FocusIn>", lambda e: id_entry.delete('0', 'end'))
id_entry.grid(row=1, column=0, padx=5, pady=5, sticky="ew")

combox_optionals = ["Pass", "Not Pass"]
status_combox = ttk.Combobox(widgets_frame, values=combox_optionals)
status_combox.current(1)
status_combox.grid(row=2, column=0, padx=5, pady=5, sticky="ew")

final_grade = ttk.Entry(widgets_frame)
final_grade.insert(0, "Final Grade")
final_grade.bind("<FocusIn>", lambda e: final_grade.delete('0', 'end'))
final_grade.grid(row=3, column=0, padx=5, pady=5, sticky="ew")  # east-west

button = ttk.Button(widgets_frame, text="Insert", command=insert_st)
button.grid(row=5, column=0, padx=5, pady=5, sticky="nsew")

# ------------------Calculator
widgets_frame2 = ttk.LabelFrame(frame, text="Calculator")
widgets_frame2.grid(row=6, column=0, padx=20, pady=20)

calculation = ["+", "*", "/", "-"]
calcu = ttk.Combobox(widgets_frame2, values=calculation)
calcu.current(0)
calcu.grid(row=8, column=0, padx=5, pady=5, sticky="ew")


num_spinbox = ttk.Spinbox(widgets_frame2, from_=1, to=student.num_student)
num_spinbox.insert(0, "num row")
num_spinbox.grid(row=7, column=0, padx=5, pady=5, sticky="ew")


row_grade = ttk.Entry(widgets_frame2, validate="key")
row_grade.insert(0, " number")
row_grade.bind("<FocusIn>", lambda e: row_grade.delete('0', 'end'))
row_grade.grid(row=9, column=0, padx=5, pady=5, sticky="ew")  # east-west

button_res = ttk.Button(widgets_frame2, text="   =   ", command=cal)
button_res.grid(row=10, column=0, padx=5, pady=5, sticky="nsew")

answer = ttk.Entry(widgets_frame2)
answer.grid(row=11, column=0, padx=5, pady=5, sticky="ew")

# --------------------functions
widgets_frame3 = ttk.LabelFrame(frame, text="functions")
widgets_frame3.grid(row=6, column=1, padx=20, pady=20)

func = ["MIN", "MAX", "SUM", "AVERAGE"]
func = ttk.Combobox(widgets_frame3, values=func)
func.current(0)
func.grid(row=7, column=1, padx=5, pady=5, sticky="ew")

from_row = ttk.Spinbox(widgets_frame3, from_=1, to=2)
from_row.insert(0, "from row- ")
from_row.grid(row=8, column=1, padx=5, pady=5, sticky="ew")  # east-west

to_row = ttk.Spinbox(widgets_frame3, from_=1, to=2)
to_row.insert(0, "to row- ")
to_row.grid(row=9, column=1, padx=5, pady=5, sticky="ew")  # east-west

button_func = ttk.Button(widgets_frame3, text="   =   ", command=func_cal)
button_func.grid(row=10, column=1, padx=5, pady=5, sticky="nsew")

answer_func = ttk.Entry(widgets_frame3)
answer_func.grid(row=11, column=1, padx=5, pady=5, sticky="ew")

# --------------change student
widgets_frame4 = ttk.LabelFrame(frame, text="changes")
widgets_frame4.grid(row=0, column=2, padx=20, pady=20)

num_change = ttk.Entry(widgets_frame4)
num_change.insert(0, "Number")
num_change.bind("<FocusIn>", lambda e: num_change.delete('0', 'end'))
num_change.grid(row=1, column=2, padx=5, pady=(0, 5), sticky="ew")  # east-west

student_name_change = ttk.Entry(widgets_frame4)
student_name_change.insert(0, "Name")
student_name_change.bind("<FocusIn>", lambda e: student_name_change.delete('0', 'end'))
student_name_change.grid(row=2, column=2, padx=5, pady=(0, 5), sticky="ew")  # east-west

id_change = ttk.Entry(widgets_frame4)
id_change.insert(0, "Id")
id_change.bind("<FocusIn>", lambda e: id_change.delete('0', 'end'))
id_change.grid(row=3, column=2, padx=5, pady=5, sticky="ew")  # east-west

combox_optionals_change = ["Pass", "Not Pass"]
status_combox_change = ttk.Combobox(widgets_frame4, values=combox_optionals_change)
status_combox_change.current(1)
status_combox_change.grid(row=4, column=2, padx=5, pady=5, sticky="ew")

final_grade_change = ttk.Entry(widgets_frame4)
final_grade_change.insert(0, "Final Grade")
final_grade_change.bind("<FocusIn>", lambda e: final_grade_change.delete('0', 'end'))
final_grade_change.grid(row=5, column=2, padx=5, pady=5, sticky="ew")  # east-west

button_change = ttk.Button(widgets_frame4, text="Change", command=change_st)
button_change.grid(row=6, column=2, padx=5, pady=5, sticky="nsew")

# --------------------sheet
excel_frame = ttk.Frame(frame)
excel_frame.grid(row=0, column=1, pady=10)
excel_scroll = ttk.Scrollbar(excel_frame)
excel_scroll.pack(side="right", fill="y")

columns = ("Number", "Name", "Id", "Pass", "grades")
excel_view = ttk.Treeview(excel_frame, show="headings", yscrollcommand=excel_scroll.set, columns=columns, height=13, )

excel_view.column("Number", width=100)
excel_view.column("Name", width=100)
excel_view.column("Id", width=100)
excel_view.column("Pass", width=100)
excel_view.column("grades", width=100)

excel_view.pack()
excel_scroll.config(command=excel_view.yview)

# ----------- save & load
widgets_frame4 = ttk.LabelFrame(frame)
widgets_frame4.grid(row=10, column=2, padx=20, pady=20)

button_save = ttk.Button(widgets_frame4, text="save", command=save)
button_save.grid(row=11, column=2, padx=5, pady=5, sticky="nsew")

button_load = ttk.Button(widgets_frame4, text="load", command=load_button_callback)
button_load.grid(row=12, column=2, padx=5, pady=5, sticky="nsew")

#-----------message
msg = ttk.Label(root, text='', background='#296b73', foreground='#880808')
msg.pack(side=tk.TOP,pady=(10, 20))








# Press the green button in the gutter to run the script.
if __name__ == '__main__':

    if len(sys.argv) > 1 and sys.argv[1] == "--help":
        print(
            "This project presents software that allows the user to create and manage a spreadsheet, enter into it data, perform calculations and more, similar to the software Excel or Google Sheets. "
            "This sheet is addressed to test reviewers in particular. This software allows you to enter value about the student. Change values in an existing student. "
            "This software supports changing existing cells on basic calculations. In addition, there are special functions that allow you to perform comprehensive calculations on a number of students that you choose as you wish. "
            "Hope you will enjoy.")
    else:
        data()
        root.mainloop()



