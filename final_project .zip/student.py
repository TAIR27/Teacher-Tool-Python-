class Student:
    num_student = 0

    def __init__(self, num, name, id, status, grade):
        self.__num = num
        self.__name = name
        self.__id = id
        self.__status = status
        self.__grade = grade

    # Method to convert instance to dictionary
    def to_dict(self):
        return {
            'num': self.__num,
            'name': self.__name,
            'id': self.__id,
            'status': self.__status,
            'grade': self.__grade
        }

    def __str__(self):
        res = "(" + str(self.__name) + "," + str(self.__id) + "," + str(self.__status) + "," + str(
            self.__grade) + ")"
        return res

    def get_num(self):
        return self.__num

    def get_name(self):
        return self.__name

    def get_id(self):
        return self.__id

    def get_status(self):
        return self.__status

    def get_grade(self):
        return self.__grade

    def set_name(self, name):
        self.__name = name

    def set_id(self, id):
        self.__id = id

    def set_status(self, status):
        self.__status = status

    def set_grade(self, grade):
        self.__grade = grade

    def from_dict(self, data):
        return self(**data)


class Sheet:

    def __init__(self):
        self.students = []

    def __str__(self):
        res = "["
        for i in self.students:
            res += "(" + str(i.get_num()) + "," + str(i.get_name()) + "," + str(i.get_id()) + "," + str(
                i.get_status()) + "," + str(i.get_grade()) + ")"
        res += "]"
        return res

    def add_student(self, student):
        self.students.append(student)

    def get_list(self):
        return self.students

    def get_tup_to_lst(self, num):
        if num == 0:
            return [str(self.students[num].get_num()), str(self.students[num].get_name()),
                    str(self.students[num].get_id()), str(self.students[num].get_status()),
                    str(self.students[num].get_grade())]

        lst = []
        for st in self.students[1:]:
            lst.append(
                [str(st.get_num()), str(st.get_name()), str(st.get_id()), str(st.get_status()), str(st.get_grade())])

        return lst

    def insetion(self, i):
        return [str(self.students[i].get_num()), str(self.students[i].get_name()), str(self.students[i].get_id()),str(self.students[i].get_status()),str(self.students[i].get_grade())]

    def grades(self):
        lst = []
        for i in range(len(self.students) - 1):
            lst.append(int(self.students[i + 1].get_grade()))
        return lst

    def change_student(self, num, name, id, status, grade):
        if name != "Name":
            self.students[num].set_name(name)
        if id != "Id":
            self.students[num].set_id(id)

        if status != self.students[num].get_status():
            self.students[num].set_status(status)

        if grade != "Final Grade":
            self.students[num].set_grade(grade)

    def load_lst(self,lst):
        self.students=lst
